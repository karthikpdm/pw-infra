import json
import boto3
import os
import base64
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['DYNAMODB_TABLE_NAME'])
def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event))
        
        for record in event['Records']:
            kinesis_data = record['kinesis']['data']
            decoded_data = base64.b64decode(kinesis_data)
            telemetry_data = json.loads(decoded_data)
            item = {
                'VIN': telemetry_data['VIN'],
                'timestamp': telemetry_data['timestamp'],
                'location': {
                    'lat': Decimal(str(telemetry_data['location']['lat'])),
                    'long': Decimal(str(telemetry_data['location']['long']))
                },
                'accuracy': {
                    'Horizontal': Decimal(str(telemetry_data['accuracy']['Horizontal']))
                },
                'heading': Decimal(str(telemetry_data['heading'])),
                'speed': Decimal(str(telemetry_data['speed'])),
                'batteryVoltage': Decimal(str(telemetry_data['batteryVoltage'])),
                'batterySOC': Decimal(str(telemetry_data['batterySOC']))
            }
            
            print("Inserting item:", json.dumps(item, default=str))
            table.put_item(Item=item)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Data successfully stored in DynamoDB')
        }
    
    except Exception as e:
        print(f"Error processing record: {str(e)}")
        raise e
