import json
import boto3
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the IoT client 
iot_client = boto3.client('iot-data')

def lambda_handler(event, context):
   response_headers = {
       'Access-Control-Allow-Origin': '*', 
       'Access-Control-Allow-Headers': 'Content-Type',
       'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
   }

   # Handle OPTIONS request for CORS preflight
   if event['httpMethod'] == 'OPTIONS':
       return {
           'statusCode': 200,
           'headers': response_headers,
           'body': ''
       }
       
   try:
       # Log incoming event
       logger.info(f"Received event: {json.dumps(event)}")

       # Extract parameters
       thing_name = event['queryStringParameters']['thingName']
       shadow_name = event['queryStringParameters']['shadowName'] 
       action = event['queryStringParameters']['action']

       if action == 'get':
           response = iot_client.get_thing_shadow(
               thingName=thing_name,
               shadowName=shadow_name
           )
           shadow_state = json.loads(response['payload'].read())
           return {
               'statusCode': 200,
               'headers': response_headers,
               'body': json.dumps(shadow_state)
           }

       elif action == 'update':
           # Get request body and parse JSON
           body = event['body']
           logger.info(f"Request body: {body}")
           
           # Parse body - handle both string and dict cases
           if isinstance(body, str):
               body = json.loads(body)
               if isinstance(body, str):  # Handle double encoded JSON
                   body = json.loads(body)
                   
           # Create shadow document
           shadow_document = {
               'state': {
                   'desired': body
               }
           }
           
           logger.info(f"Shadow document to update: {json.dumps(shadow_document)}")

           # Update shadow
           response = iot_client.update_thing_shadow(
               thingName=thing_name,
               shadowName=shadow_name,
               payload=json.dumps(shadow_document).encode('utf-8')
           )

           return {
               'statusCode': 200,
               'headers': response_headers, 
               'body': json.dumps({'message': 'Shadow updated successfully'})
           }

       else:
           return {
               'statusCode': 400,
               'headers': response_headers,
               'body': json.dumps({'error': 'Invalid action'})
           }

   except Exception as e:
       logger.error(f"Error: {str(e)}")
       return {
           'statusCode': 500,
           'headers': response_headers,
           'body': json.dumps({'error': str(e)})
       }