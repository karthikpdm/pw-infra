#!/usr/bin/env python

import json
import os
import uuid
import boto3
import datetime
import time

def is_valid_ml_event(ml_data_dynamo_table, event_id):
    try:
        print(f"Attempting to retrieve event_id: {event_id}")

        # Use the table resource to get the item
        response = ml_data_dynamo_table.get_item(
            Key={'event_id': event_id}
        )

        ml_item = response.get('Item')

        print(f"Retrieved ML Item: {ml_item}")

        if ml_item:
            print(f"Valid ML event found for event_id: {event_id}")
            return True
        
        print(f"No item found for event_id: {event_id}")
        return False
    
    except Exception as e:
        print(f"Error retrieving event: {e}")
        return False

def handler(event, context):
    assetID = str(uuid.uuid4())
    sourceS3Bucket = event['Records'][0]['s3']['bucket']['name']
    sourceS3Key = event['Records'][0]['s3']['object']['key']
    sourceS3 = 's3://' + sourceS3Bucket + '/' + sourceS3Key
    sourceS3Basename = os.path.splitext(os.path.basename(sourceS3))[0]
    destinationS3 = 's3://' + os.environ['DestinationBucket']
    mediaConvertRole = os.environ['MediaConvertRole']
    cloudfront_domain = os.environ['CloudFrontDomain']
    ml_data_table = os.environ['MLDataTableName']
    region = os.environ['AWS_DEFAULT_REGION']
    statusCode = 200
    body = {}
    
    jobMetadata = {'assetID': assetID}
    
    try:
        dynamodb = boto3.resource('dynamodb', region_name=region)
        ml_data_dynamo_table = dynamodb.Table(ml_data_table)
        print("ml-data", ml_data_dynamo_table)
        event_id = os.path.splitext(os.path.basename(sourceS3Key))[0]
        print("event_id", event_id)
     
        while not is_valid_ml_event(ml_data_dynamo_table, event_id):
            print(f"Waiting for event {event_id} to be available in DynamoDB...")
            time.sleep(2)  # Sleep for 2 seconds before checking again
        
        with open('job.json') as json_data:
            jobSettings = json.load(json_data)
        
        mc_client = boto3.client('mediaconvert', region_name=region)
        endpoints = mc_client.describe_endpoints()
        
        client = boto3.client('mediaconvert', region_name=region, 
                              endpoint_url=endpoints['Endpoints'][0]['Url'], 
                              verify=False)
        
        jobSettings['Inputs'][0]['FileInput'] = sourceS3
        
        S3KeyHLS = 'assets/' + assetID + '/HLS/' + sourceS3Basename
        jobSettings['OutputGroups'][0]['OutputGroupSettings']['HlsGroupSettings']['Destination'] \
            = destinationS3 + '/' + S3KeyHLS
        
        S3KeyWatermark = 'assets/' + assetID + '/MP4/' + sourceS3Basename
        jobSettings['OutputGroups'][1]['OutputGroupSettings']['FileGroupSettings']['Destination'] \
            = destinationS3 + '/' + S3KeyWatermark
        
        S3KeyThumbnails = 'assets/' + assetID + '/Thumbnails/' + sourceS3Basename
        jobSettings['OutputGroups'][2]['OutputGroupSettings']['FileGroupSettings']['Destination'] \
            = destinationS3 + '/' + S3KeyThumbnails     
        
        job = client.create_job(Role=mediaConvertRole, UserMetadata=jobMetadata, Settings=jobSettings)
        
        video_path = f'assets/{assetID}/MP4/{sourceS3Basename}.mp4'
        cloudfront_video_url = f'{cloudfront_domain}/{video_path}'
        
        ml_data_dynamo_table.update_item(
            Key={'event_id': event_id},
            UpdateExpression='SET event_video_url = :video_url',
            ExpressionAttributeValues={
                ':video_url': cloudfront_video_url
            }
        )
        
        print(f"Updated valid ML event: {event_id}")
    
    except Exception as e:
        print(f"Error processing event {event_id}: {e}")
        statusCode = 500
        raise
    
    finally:
        return {
            'statusCode': statusCode,
            'body': json.dumps(body),
            'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'}
        }
